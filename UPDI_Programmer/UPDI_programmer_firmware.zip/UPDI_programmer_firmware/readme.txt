For ATmega8:
---------------
avrdude -c usbasp -p m8 -U flash:w:jtag2updi_m8.hex -U lfuse:w:0xff:m -U hfuse:w:0xd9:m

For ATmega88p:
---------------
avrdude -c usbasp -p m88p -U flash:w:jtag2updi_m88p.hex -U lfuse:w:0xff:m -U hfuse:w:0xdb:m -U efuse:w:0xfd:m

For ATmega168p:
---------------
avrdude -c usbasp -p m168p -U flash:w:jtag2updi_m168p.hex -U lfuse:w:0xff:m -U hfuse:w:0xdb:m -U efuse:w:0xfd:m

For ATmega328p:
---------------
avrdude -c usbasp -p m328p -U flash:w:jtag2updi_m328p.hex -U lfuse:w:0xff:m -U hfuse:w:0xdb:m -U efuse:w:0xfd:m


For more information and source code visit https://github.com/ElTangas/jtag2updi
