Uploading Firmware without using Bootloader
===========================================
Connect a UPDI (HV) Programmer to the UPDI Header.
Set SELFPRG jumper to "UPDI" before uploading and remove it afterwards!

For ATtiny1604:
---------------
avrdude -C avrdude.conf -c jtag2updi -P /dev/ttyUSB0 -p t1604 -e -U fuse0:w:0x00:m -U fuse1:w:0b00000000:m -U fuse2:w:0x02:m -U fuse4:w:0x00:m -U fuse5:w:0xC7:m -U fuse6:w:0x03:m -U fuse7:w:0x00:m -U fuse8:w:0x00:m -U flash:w:jtag2updihv_t1604.hex:i

For ATtiny1614:
---------------
avrdude -C avrdude.conf -c jtag2updi -P /dev/ttyUSB0 -p t1614 -e -U fuse0:w:0x00:m -U fuse1:w:0b00000000:m -U fuse2:w:0x02:m -U fuse4:w:0x00:m -U fuse5:w:0xC7:m -U fuse6:w:0x03:m -U fuse7:w:0x00:m -U fuse8:w:0x00:m -U flash:w:jtag2updihv_t1614.hex:i


Installing Bootloader
=====================
Connect a UPDI HV Programmer to the UPDI Header.
Set SELFPRG jumper to UPDI before uploading and remove it afterwards!
Warning: PA0 will be configured as RESET pin. You need an HV programmer to undo this change! 

For ATtiny1604:
---------------
avrdude -C avrdude.conf -c jtag2updi -P /dev/ttyUSB0 -p t1604 -e -U fuse0:w:0x00:m -U fuse1:w:0b00000000:m -U fuse2:w:0x02:m -U fuse4:w:0x00:m -U fuse5:w:0b11001000:m -U fuse6:w:0x03:m -Ufuse7:w:0x00:m -U fuse8:w:0x02:m -U flash:w:optiboot_txy4_rst.hex:i 

For ATtiny1614:
---------------
avrdude -C avrdude.conf -c jtag2updi -P /dev/ttyUSB0 -p t1614 -e -U fuse0:w:0x00:m -U fuse1:w:0b00000000:m -U fuse2:w:0x02:m -U fuse4:w:0x00:m -U fuse5:w:0b11001000:m -U fuse6:w:0x03:m -U fuse7:w:0x00:m -U fuse8:w:0x02:m -U flash:w:optiboot_txy4_rst.hex:i


Uploading Firmware with an installed Bootloader
===============================================
Connect the device to a USB port of your PC.
Set SELFPRG jumper to "USB" before uploading and remove it afterwards!

For ATtiny1604:
---------------
avrdude -C avrdude.conf -v -p t1604 -c arduino -P /dev/ttyUSB0 -D -b 115200 -U flash:w:jtag2updihv_t1604_opti.hex:i

For ATtiny1614:
---------------
avrdude -C avrdude.conf -v -p t1614 -c arduino -P /dev/ttyUSB0 -D -b 115200 -U flash:w:jtag2updihv_t1614_opti.hex:i


AVRDUDE Options:
================
-C  config file
-c  programmer
-P  COM port
-p  part number of target device
-e  perform chip erase


Further Information
===================
For more information and source code visit: https://github.com/Dlloydev/jtag2updi
