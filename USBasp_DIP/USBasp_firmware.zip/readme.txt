Set fuses and burn firmware
---------------------------
avrdude -c usbasp -p m8 -U lfuse:w:0x9f:m -U hfuse:w:0xc9:m -U flash:w:usbasp_m8_2020-09-14.hex

Set JP1 and JP2 prior to uploading firmware!

For more information and source code visit https://www.fischl.de/usbasp.
For the improved version visit https://github.com/nerdralph/usbasp.
