Set fuses and burn firmware
---------------------------
avrdude -c usbtiny -p m8 -U lfuse:w:0x9f:m -U hfuse:w:0xc8:m -U flash:w:usbasp.atmega8.2011-05-28.hex

Set JP1 and JP2 prior to uploading firmware!

For more information and source code visit https://www.fischl.de/usbasp/
