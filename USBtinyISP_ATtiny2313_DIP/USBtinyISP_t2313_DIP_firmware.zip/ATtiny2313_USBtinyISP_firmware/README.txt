Use ICSP-IN header to upload the firmware. To avoid interference with the
buffer remove PWROUT jumper and disconnect any device from ICSP-OUT header
prior to uploading the firmware.

avrdude -c usbtiny -pt2313 -U hfuse:w:0xdf:m -U lfuse:w:0xef:m
avrdude -c usbtiny -B 1 -pt2313 -U flash:w:main.hex

For more information and source code visit https://learn.adafruit.com/usbtinyisp
