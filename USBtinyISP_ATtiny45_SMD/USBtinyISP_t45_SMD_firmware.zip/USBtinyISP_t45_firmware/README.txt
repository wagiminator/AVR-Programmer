Upload the firmware first prior to burning the fuses!
After burning the fuses the RESET pin will be deactivated und uploading firmware
with normal programmers won't be possible anymore. You will have to use a
high voltage serial programmer to reset the fuses.
Change "t45" to "t85" if using an ATtiny85.

avrdude -c usbtiny -p t45 -U flash:w:usbtiny45.hex
avrdude -c usbtiny -p t45 -V -U lfuse:w:0xe1:m -U hfuse:w:0x5d:m -U efuse:w:0xff:m
